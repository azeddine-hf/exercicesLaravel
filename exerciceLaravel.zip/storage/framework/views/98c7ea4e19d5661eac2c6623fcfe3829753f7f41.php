<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item <?php if(Route::currentRouteName() != 'countries'): ?> active <?php endif; ?>">
                    <?php if(Route::currentRouteName() != 'countries'): ?>
                        <a href="<?php echo e(route('countries')); ?>">Countries</a>
                    <?php else: ?>
                        <span class="text-muted">Countries</span>
                    <?php endif; ?>
                </li>
                <li class="breadcrumb-item <?php if(Route::currentRouteName() != 'cities'): ?> active <?php endif; ?>">
                    <?php if(Route::currentRouteName() != 'cities'): ?>
                        <a href="<?php echo e(route('cities')); ?>">Cities</a>
                    <?php else: ?>
                        <span class="text-muted">Cities</span>
                    <?php endif; ?>
                </li>
                <li class="breadcrumb-item <?php if(Route::currentRouteName() != 'persons'): ?> active <?php endif; ?>">
                    <?php if(Route::currentRouteName() != 'persons'): ?>
                        <a href="<?php echo e(route('persons')); ?>">People</a>
                    <?php else: ?>
                        <span class="text-muted">People</span>
                    <?php endif; ?>
                </li>
            </ol>
        </nav>

        <div class="row mb-3">
            <div class="col-md-12 text-end">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPersonModal">
                    Add Person
                </button>
            </div>
        </div>

        <div class="sessionMessage m-2">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
            <?php endif; ?>
        </div>

        <table id="persons_table" class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>City</th>
                <th>Coutry</th>
            </tr>
            </thead>
            <tbody>
            
            <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($person->id); ?></td>
                    <td><?php echo e($person->name); ?></td>
                    <td><?php echo e($person->city->name); ?></td>
                    <td><?php echo e($person->city->country->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <div class="modal fade" id="addPersonModal" tabindex="-1" aria-labelledby="addPersonModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addPersonModalLabel">Add Person</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('persons.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="name" class="form-label">Person Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="city_id" class="form-label">City</label>
                                <select class="form-select" id="city_id" name="city_id" required>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#persons_table').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\exerciceLaravel\resources\views/person.blade.php ENDPATH**/ ?>